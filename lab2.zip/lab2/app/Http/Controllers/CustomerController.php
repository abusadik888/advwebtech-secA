<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerController extends Controller
{
    //
    function list(){
        //$customers = array();
        $customers = array();
        for($i=1;$i<=10;$i++){
            $customer = array(
                "id"=>$i,
                "name"=>"customer $i",
                "dob"=>"12.12.12"
            );
            $customers[] = (object)$customer;
        }

        return view('customers.list')
               ->with('customers',$customers);
    }
    //
    function home($id){
       
        $name = "<h1>Karim</h1>";
        $dob = "12.12.12";
        return view('customers.home')
        ->with('n',$name)
        ->with('id',$id)
        ->with('dob',$dob);
    }
    function create(){
        return view('customers.create');
    }
    function createSubmit(Request $req){

        //$req->validate([],[]);
        $this->validate($req,
             [
                "name"=>"required|max:10",
                "id"=>"required|regex:/^([0-9]{2}-[0-9]{5}-[1-3]{1})+$/i",
                "dob"=>"required",
                "email"=>'required|email',
                "password"=>"required",
                "conf_password"=>"required|same:password"
             ],
             [
                 "name.required"=> "Please provide your name",
                 "name.max"=> "Name should not exceed 10 characters"
             ]
            );

        return "Submitted with valid value";
    }
}
