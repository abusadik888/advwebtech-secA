@extends('layouts.main')
@section('content')
<h1> Customer Home</h1>
Name: Customer {{$id}}
Id: {{$id}}
@endsection
