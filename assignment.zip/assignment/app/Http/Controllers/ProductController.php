<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    function list(){
       
        $products = array();
        for($i=1;$i<=10;$i++){
            $product = array(
                "id"=>$i,
                "name"=>"product $i",
                "price"=>"12"
            );
            $products[] = (object)$product;
        }

        return view('products.list')
               ->with('products',$products);
    }
    //
    function home($id){
       
        $name = "<h1>Cake</h1>";
        $price = "12";
        return view('products.home')
        ->with('n',$name)
        ->with('id',$id)
        ->with('price',$price);
    }
    function create(){
        return view('products.create');
    }
    function createSubmit(Request $req){

        //$req->validate([],[]);
        $this->validate($req,
             [
                "name"=>"required|max:10",
                "id"=>"required",
                "price"=>"required",
             ],

            );

        return "Submitted with valid value";
    }
}
