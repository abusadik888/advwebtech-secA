@extends('layouts.main')
@section('content')
<h1> Product Home</h1>
Name: Product {{$id}}
Id: {{$id}}
Cgpa 2.45
@endsection
