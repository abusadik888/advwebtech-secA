@extends('layouts.main')
@section('content')
   
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Id</th>
            <th>Price</th>
        </tr>
        @foreach($products as $p)
            <tr>
                <td><a href="{{route('product.details',['id'=>$p->id,'name'=>$p->name])}}">{{$p->name}}</a></td>
                <td>{{$p->id}}</td>
                <td>{{$p->price}}</td>
            </tr>
        @endforeach
    </table>
@endsection