@extends('layouts.main')
@section('content')
<h1>This is our home page</h1>
@endsection