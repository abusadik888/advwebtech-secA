<a href="/product/home"> Product Home</a>
<a href="/">Home</a>
<a href="/welcome">Welcome</a>
<a href="{{route('product.list')}}">List</a>
